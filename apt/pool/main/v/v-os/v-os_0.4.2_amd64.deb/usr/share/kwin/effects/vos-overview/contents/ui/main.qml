import QtQuick
import org.kde.kwin as KWinComponents

// V-Overview: every window of the current desktop at a glance, as live pictures
// (Meta+Tab, or "Show all windows" in Home). Made as a QML effect of KWin, which
// alone can draw other programs' windows; it cannot use V-OS's own QML modules,
// so its few colours are written here.
KWinComponents.SceneEffect {
    id: effect

    property bool activated: false
    readonly property int animationDuration: 200

    // (Kept as a property so that the component lives as long as the effect.)
    property var screenView: Qt.createComponent("ScreenView.qml")

    delegate: screenView

    KWinComponents.ShortcutHandler {
        name: "V-Overview"
        text: "Show all windows"
        sequence: "Meta+Tab"
        onActivated: effect.toggle()
    }

    Timer {
        id: deactivateTimer

        interval: effect.animationDuration
        onTriggered: effect.visible = false
    }

    function toggle() {
        if (activated)
            deactivate();
        else
            activate();
    }

    function activate() {
        if (activated || deactivateTimer.running)
            return;
        visible = true;
        activated = true;
    }

    function deactivate() {
        if (!activated)
            return;
        activated = false;
        deactivateTimer.start();
    }
}
