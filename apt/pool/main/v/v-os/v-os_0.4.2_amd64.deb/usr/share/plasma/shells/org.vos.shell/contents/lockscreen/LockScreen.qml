import QtQuick
import QtQuick.Shapes

// The lock screen of V-OS ("Стекло"): the field of colour, the time and the date; a touch or a
// key brings the user and the password. Shown by KDE's screen locker (kscreenlocker_greet),
// which keeps the computer locked and falls back to its own built-in locker if this cannot load.
// Its API: `authenticator` (startAuthenticating, respond, succeeded/failed), and the properties
// and signals of this root item.
Item {
    id: root

    // Properties and signals the screen locker looks for.
    property bool viewVisible: false
    property bool suspendToRamSupported: false
    property bool suspendToDiskSupported: false
    property string notification
    signal suspendToDisk()
    signal suspendToRam()
    signal clearPassword()
    signal notificationRepeated()

    readonly property string language: Qt.locale().uiLanguages.length > 0 ? Qt.locale().uiLanguages[0] : Qt.locale().name
    readonly property bool russian: language.startsWith("ru")
    readonly property var languageLocale: Qt.locale(language.replace("-", "_"))
    property bool asking: false
    property string message: ""
    property date now: new Date()

    function tr(english, russian) {
        return root.russian ? russian : english;
    }

    function wake() {
        if (!root.asking) {
            root.asking = true;
            authenticator.startAuthenticating();
        }
        password.forceActiveFocus();
    }

    implicitWidth: 800
    implicitHeight: 600

    Connections {
        target: authenticator

        function onFailed(kind) {
            if (kind !== 0)
                return;
            root.message = root.tr("That password did not fit.", "Пароль не подошёл.");
            password.text = "";
            shake.restart();
            authenticator.startAuthenticating();
        }

        function onSucceeded() {
            Qt.quit();
        }

        function onPromptForSecretChanged() {
            password.forceActiveFocus();
        }
    }

    onClearPassword: password.text = ""

    Timer {
        interval: 1000
        repeat: true
        running: true
        onTriggered: root.now = new Date()
    }

    // ---- The field of colour --------------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        gradient: Gradient {
            GradientStop { position: 0.0; color: "#121c55" }
            GradientStop { position: 0.55; color: "#4a2d8d" }
            GradientStop { position: 1.0; color: "#e0607a" }
        }
    }

    component Light: Shape {
        id: light

        property color tone

        ShapePath {
            strokeColor: "transparent"
            fillGradient: RadialGradient {
                centerX: light.width / 2
                centerY: light.height / 2
                centerRadius: light.width / 2
                focalX: light.width / 2
                focalY: light.height / 2
                GradientStop { position: 0; color: light.tone }
                GradientStop { position: 1; color: Qt.rgba(light.tone.r, light.tone.g, light.tone.b, 0) }
            }
            startX: 0
            startY: 0
            PathLine { x: light.width; y: 0 }
            PathLine { x: light.width; y: light.height }
            PathLine { x: 0; y: light.height }
            PathLine { x: 0; y: 0 }
        }
    }

    Light { x: -root.width * 0.10; y: root.height * 0.05; width: root.width * 0.62; height: width; tone: Qt.rgba(0.25, 0.80, 1.0, 0.70) }
    Light { x: root.width * 0.48; y: -root.height * 0.35; width: root.width * 0.62; height: width; tone: Qt.rgba(1.0, 0.38, 0.72, 0.60) }
    Light { x: root.width * 0.30; y: root.height * 0.42; width: root.width * 0.70; height: width; tone: Qt.rgba(1.0, 0.80, 0.42, 0.50) }

    // A dimmer veil while the password is asked for, so that the words stay clear.
    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0.02, 0.02, 0.06, root.asking ? 0.42 : 0.12)

        Behavior on color {
            ColorAnimation { duration: 260 }
        }
    }

    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        onClicked: root.wake()
    }

    Keys.onPressed: event => {
        root.wake();
        event.accepted = false;
    }
    focus: true

    // ---- The time --------------------------------------------------------------------------------
    Column {
        anchors.horizontalCenter: parent.horizontalCenter
        y: root.asking ? parent.height * 0.10 : parent.height * 0.22
        spacing: 2

        Behavior on y {
            NumberAnimation { duration: 320; easing.type: Easing.OutCubic }
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.formatTime(root.now, "HH:mm")
            color: "white"
            font.family: "IBM Plex Sans"
            font.pixelSize: Math.min(140, root.height * 0.15)
            font.weight: Font.Light
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.now.toLocaleDateString(root.languageLocale, "dddd, d MMMM")
            color: Qt.rgba(1, 1, 1, 0.82)
            font.family: "IBM Plex Sans"
            font.pixelSize: 21
        }
    }

    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 46
        visible: !root.asking
        text: root.tr("Press a key or click to unlock", "Нажмите клавишу или щёлкните, чтобы разблокировать")
        color: Qt.rgba(1, 1, 1, 0.70)
        font.family: "IBM Plex Sans"
        font.pixelSize: 15
    }

    // ---- The user and the password ------------------------------------------------------------------
    Column {
        id: card

        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.46
        width: 340
        spacing: 16
        opacity: root.asking ? 1 : 0
        visible: opacity > 0.01

        Behavior on opacity {
            NumberAnimation { duration: 260 }
        }

        transform: Translate {
            id: offset
        }

        SequentialAnimation {
            id: shake

            NumberAnimation { target: offset; property: "x"; to: -14; duration: 60 }
            NumberAnimation { target: offset; property: "x"; to: 12; duration: 70 }
            NumberAnimation { target: offset; property: "x"; to: -8; duration: 70 }
            NumberAnimation { target: offset; property: "x"; to: 0; duration: 80 }
        }

        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: 96
            height: 96
            radius: 48
            color: Qt.rgba(1, 1, 1, 0.16)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.42)

            Text {
                anchors.centerIn: parent
                text: String(typeof kscreenlocker_userName !== "undefined" ? kscreenlocker_userName : "").charAt(0).toUpperCase()
                color: "white"
                font.family: "IBM Plex Sans"
                font.pixelSize: 40
                font.weight: Font.Light
            }
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: typeof kscreenlocker_userName !== "undefined" ? kscreenlocker_userName : ""
            color: "white"
            font.family: "IBM Plex Sans"
            font.pixelSize: 20
            font.weight: Font.Medium
        }

        Rectangle {
            width: parent.width
            height: 50
            radius: 25
            color: Qt.rgba(1, 1, 1, 0.16)
            border.width: 1
            border.color: password.activeFocus ? Qt.rgba(1, 1, 1, 0.70) : Qt.rgba(1, 1, 1, 0.32)

            TextInput {
                id: password

                objectName: "lock.password"
                anchors.fill: parent
                anchors.leftMargin: 22
                anchors.rightMargin: 56
                verticalAlignment: TextInput.AlignVCenter
                echoMode: TextInput.Password
                passwordCharacter: "●"
                color: "white"
                font.family: "IBM Plex Sans"
                font.pixelSize: 16
                clip: true
                enabled: !authenticator.graceLocked
                onAccepted: {
                    root.message = "";
                    authenticator.respond(password.text);
                }

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: password.text.length === 0
                    text: root.tr("Password", "Пароль")
                    color: Qt.rgba(1, 1, 1, 0.56)
                    font: password.font
                }
            }

            Rectangle {
                anchors.right: parent.right
                anchors.rightMargin: 7
                anchors.verticalCenter: parent.verticalCenter
                width: 36
                height: 36
                radius: 18
                color: Qt.rgba(0.965, 0.970, 1.0, password.text.length > 0 ? 0.96 : 0.5)

                Text {
                    anchors.centerIn: parent
                    text: "→"
                    color: "#17204f"
                    font.pixelSize: 18
                    font.weight: Font.DemiBold
                }

                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        root.message = "";
                        authenticator.respond(password.text);
                    }
                }
            }
        }

        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            visible: root.message.length > 0
            text: root.message
            color: "#ffd0c8"
            font.family: "IBM Plex Sans"
            font.pixelSize: 14
            wrapMode: Text.Wrap
        }
    }

    // ---- Sleep -----------------------------------------------------------------------------------------
    Rectangle {
        visible: root.asking && root.suspendToRamSupported
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 28
        width: sleepText.implicitWidth + 36
        height: 40
        radius: 20
        color: Qt.rgba(1, 1, 1, 0.16)

        Text {
            id: sleepText

            anchors.centerIn: parent
            text: root.tr("Sleep", "Сон")
            color: "white"
            font.family: "IBM Plex Sans"
            font.pixelSize: 14
        }

        MouseArea {
            anchors.fill: parent
            onClicked: root.suspendToRam()
        }
    }

    Component.onCompleted: console.info("V-OS lock screen: ready")
}
