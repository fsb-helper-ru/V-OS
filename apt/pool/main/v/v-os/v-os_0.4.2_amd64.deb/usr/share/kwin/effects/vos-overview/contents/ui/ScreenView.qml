import QtQuick
import org.kde.kirigami as Kirigami
import org.kde.kwin as KWinComponents

// One screen of V-Overview: the windows of this screen and desktop, the one used
// last first, in a grid of live pictures. A click brings a window forward, the
// cross closes it; Escape or a click beside the windows goes back.
Item {
    id: root

    readonly property QtObject targetScreen: KWinComponents.SceneView.screen
    property var windows: []
    // As square a grid as the number of windows allows, kept clear of the top bar
    // and the dock.
    readonly property int columns: Math.max(1, Math.ceil(Math.sqrt(windows.length)))
    readonly property int rows: Math.max(1, Math.ceil(windows.length / columns))
    readonly property rect area: Qt.rect(80, 90, width - 160, height - 210)
    property real shown: 0

    function collect() {
        const list = [];
        const order = KWinComponents.Workspace.stackingOrder;
        for (let i = order.length - 1; i >= 0; --i) {
            const window = order[i];
            if (!window.normalWindow || window.skipSwitcher)
                continue;
            if (window.output && root.targetScreen && window.output.name !== root.targetScreen.name)
                continue;
            if (!window.onAllDesktops && !window.desktops.includes(KWinComponents.Workspace.currentDesktop))
                continue;
            list.push(window);
        }
        windows = list;
    }

    function choose(window) {
        KWinComponents.Workspace.activeWindow = window;
        effect.deactivate();
    }

    focus: true
    Component.onCompleted: {
        collect();
        shown = Qt.binding(() => effect.activated ? 1 : 0);
    }

    Keys.onEscapePressed: effect.deactivate()
    Keys.onReturnPressed: {
        if (root.windows.length > 0)
            root.choose(root.windows[0]);
    }
    Keys.onEnterPressed: {
        if (root.windows.length > 0)
            root.choose(root.windows[0]);
    }

    Behavior on shown {
        NumberAnimation { duration: effect.animationDuration; easing.type: Easing.OutCubic }
    }

    // The desktop, darkened behind the windows.
    KWinComponents.DesktopBackground {
        activity: KWinComponents.Workspace.currentActivity
        desktop: KWinComponents.Workspace.currentDesktop
        outputName: root.targetScreen.name
        width: root.width
        height: root.height
    }

    Rectangle {
        anchors.fill: parent
        color: "#05070b"
        opacity: 0.62 * root.shown
    }

    // A click beside the windows goes back.
    MouseArea {
        anchors.fill: parent
        onClicked: effect.deactivate()
    }

    Repeater {
        model: root.windows

        delegate: Item {
            id: cell

            required property var modelData
            required property int index
            readonly property int column: index % root.columns
            readonly property int row: Math.floor(index / root.columns)
            readonly property real cellWidth: root.area.width / root.columns
            readonly property real cellHeight: root.area.height / root.rows
            readonly property real aspect: Math.max(0.3, modelData.frameGeometry.width / Math.max(1, modelData.frameGeometry.height))
            // The picture fits its cell, with room for the name under it.
            readonly property real pictureWidth: Math.max(40, Math.min(cellWidth * 0.88, (cellHeight * 0.88 - 40) * aspect))
            readonly property real pictureHeight: pictureWidth / aspect

            x: root.area.x + column * cellWidth + (cellWidth - pictureWidth) / 2
            y: root.area.y + row * cellHeight + (cellHeight - pictureHeight - 40) / 2
            width: pictureWidth
            height: pictureHeight + 40
            opacity: root.shown
            scale: 0.94 + 0.06 * root.shown

            Rectangle {
                x: -7
                y: -7
                width: cell.pictureWidth + 14
                height: cell.pictureHeight + 14
                radius: 18
                color: hover.hovered ? Qt.rgba(1, 1, 1, 0.10) : "transparent"
                border.width: hover.hovered ? 2 : 0
                border.color: Qt.rgba(1, 1, 1, 0.62)
            }

            KWinComponents.WindowThumbnail {
                wId: cell.modelData.internalId
                width: cell.pictureWidth
                height: cell.pictureHeight
                opacity: cell.modelData.minimized ? 0.55 : 1
            }

            Row {
                anchors.horizontalCenter: parent.horizontalCenter
                y: cell.pictureHeight + 14
                spacing: 8

                Kirigami.Icon {
                    anchors.verticalCenter: parent.verticalCenter
                    width: 20
                    height: 20
                    source: cell.modelData.icon
                }

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    width: Math.min(implicitWidth, cell.pictureWidth - 34)
                    text: cell.modelData.caption
                    color: "#f2f4f8"
                    font.pixelSize: 13
                    font.weight: Font.Medium
                    elide: Text.ElideRight
                }
            }

            HoverHandler {
                id: hover
            }

            TapHandler {
                onTapped: root.choose(cell.modelData)
            }

            // The cross: the window is asked to close (it may ask about unsaved work).
            Rectangle {
                visible: hover.hovered
                x: cell.pictureWidth - width / 2 - 4
                y: -height / 2 + 4
                width: 28
                height: 28
                radius: 14
                color: closeTap.pressed ? "#3a3f4a" : "#262a33"
                border.width: 1
                border.color: Qt.rgba(1, 1, 1, 0.18)

                Text {
                    anchors.centerIn: parent
                    text: "×"
                    color: "#f2f4f8"
                    font.pixelSize: 17
                }

                TapHandler {
                    id: closeTap
                    onTapped: cell.modelData.closeWindow()
                }
            }
        }
    }
}
