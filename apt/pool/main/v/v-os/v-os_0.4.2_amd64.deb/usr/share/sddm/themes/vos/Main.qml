import QtQuick

// The login screen of V-OS, as SDDM loads it. This file uses only QtQuick, which every login
// screen has; the V-OS look is in Login.qml. If that cannot be shown (a module missing after a
// broken update, an error in it), a plain login stands in, with the user, the password and the
// choice of session: the login screen never leaves the computer without a way in.
Item {
    id: root

    readonly property bool russian: (Qt.locale().uiLanguages.length > 0 ? Qt.locale().uiLanguages[0] : Qt.locale().name).startsWith("ru")

    function tr(english, russian) {
        return root.russian ? russian : english;
    }

    width: 1920
    height: 1080

    Loader {
        id: look

        anchors.fill: parent
        focus: status === Loader.Ready
        source: "Login.qml"
        onStatusChanged: {
            if (status === Loader.Error)
                console.warn("V-OS login: the plain login stands in");
        }
    }

    Loader {
        anchors.fill: parent
        active: look.status === Loader.Error
        focus: active
        sourceComponent: plain
    }

    Component {
        id: plain

        Rectangle {
            id: page

            property int sessionIndex: sessionModel.lastIndex >= 0 ? sessionModel.lastIndex : 0
            property string message: ""

            color: "#0a0c0f"

            Connections {
                target: sddm

                function onLoginFailed() {
                    page.message = root.tr("That password did not fit. Try again.", "Пароль не подошёл. Попробуйте ещё раз.");
                    password.text = "";
                    password.forceActiveFocus();
                }
            }

            // V-OS's session first, when the computer has it.
            Repeater {
                model: sessionModel

                delegate: Item {
                    required property int index
                    required property string file

                    Component.onCompleted: {
                        if (String(file).endsWith("vos.desktop"))
                            page.sessionIndex = index;
                    }
                }
            }

            Column {
                anchors.centerIn: parent
                width: 360
                spacing: 14

                Text {
                    text: "V-OS"
                    color: "white"
                    font.pixelSize: 40
                    font.weight: Font.Light
                }

                Text {
                    width: parent.width
                    text: root.tr("Name", "Имя")
                    color: Qt.rgba(1, 1, 1, 0.6)
                    font.pixelSize: 13
                }

                Rectangle {
                    width: parent.width
                    height: 42
                    radius: 10
                    color: Qt.rgba(1, 1, 1, 0.08)

                    TextInput {
                        id: user

                        anchors.fill: parent
                        anchors.margins: 12
                        verticalAlignment: TextInput.AlignVCenter
                        color: "white"
                        font.pixelSize: 16
                        text: userModel.lastUser
                        KeyNavigation.tab: password
                    }
                }

                Text {
                    width: parent.width
                    text: root.tr("Password", "Пароль")
                    color: Qt.rgba(1, 1, 1, 0.6)
                    font.pixelSize: 13
                }

                Rectangle {
                    width: parent.width
                    height: 42
                    radius: 10
                    color: Qt.rgba(1, 1, 1, 0.08)

                    TextInput {
                        id: password

                        anchors.fill: parent
                        anchors.margins: 12
                        verticalAlignment: TextInput.AlignVCenter
                        color: "white"
                        font.pixelSize: 16
                        echoMode: TextInput.Password
                        focus: true
                        onAccepted: sddm.login(user.text, password.text, page.sessionIndex)
                    }
                }

                Text {
                    width: parent.width
                    visible: page.message.length > 0
                    text: page.message
                    color: "#ff5a47"
                    font.pixelSize: 14
                    wrapMode: Text.Wrap
                }

                Text {
                    width: parent.width
                    text: root.tr("Session", "Сеанс")
                    color: Qt.rgba(1, 1, 1, 0.6)
                    font.pixelSize: 13
                }

                // Every session of the computer, the chosen one marked.
                Column {
                    width: parent.width
                    spacing: 4

                    Repeater {
                        model: sessionModel

                        delegate: Rectangle {
                            required property int index
                            required property string name
                            required property string file

                            width: parent.width
                            height: 36
                            radius: 8
                            color: index === page.sessionIndex ? Qt.rgba(0.68, 0.75, 1, 0.25) : Qt.rgba(1, 1, 1, 0.05)

                            Text {
                                anchors.verticalCenter: parent.verticalCenter
                                x: 12
                                text: String(file).endsWith("vos.desktop") ? name : root.tr("Fallback desktop", "Резервный рабочий стол")
                                color: "white"
                                font.pixelSize: 14
                            }

                            MouseArea {
                                anchors.fill: parent
                                onClicked: page.sessionIndex = index
                            }
                        }
                    }
                }

                Row {
                    spacing: 10

                    Rectangle {
                        width: 140
                        height: 40
                        radius: 20
                        color: "#aebfff"

                        Text {
                            anchors.centerIn: parent
                            text: root.tr("Log in", "Войти")
                            color: "#0a0c0f"
                            font.pixelSize: 15
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: sddm.login(user.text, password.text, page.sessionIndex)
                        }
                    }

                    Rectangle {
                        visible: sddm.canReboot
                        width: 140
                        height: 40
                        radius: 20
                        color: Qt.rgba(1, 1, 1, 0.08)

                        Text {
                            anchors.centerIn: parent
                            text: root.tr("Restart", "Перезагрузить")
                            color: "white"
                            font.pixelSize: 15
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: sddm.reboot()
                        }
                    }
                }
            }
        }
    }
}
