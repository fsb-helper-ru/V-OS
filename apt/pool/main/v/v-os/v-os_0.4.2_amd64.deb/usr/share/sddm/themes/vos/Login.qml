import QtQuick
import QtQuick.Effects

// The login screen of V-OS (loaded by Main.qml, which stands in with a plain login if this
// cannot be shown): the horizon of the V-OS desktop, the time, the user and the password. It
// starts the V-OS session; the session button at the bottom left offers the others the
// computer has (KDE Plasma's among them), the way back when V-OS cannot start. Shown by SDDM
// (the system's login manager); its API: `sddm`, `userModel`, `sessionModel`, `keyboard`, `config`.
Item {
    id: root

    // The language of the interface (dates are named in it too, as on the V-OS desktop, whatever
    // the computer's format for dates is).
    readonly property string language: Qt.locale().uiLanguages.length > 0 ? Qt.locale().uiLanguages[0] : Qt.locale().name
    readonly property bool russian: language.startsWith("ru")
    readonly property var languageLocale: Qt.locale(language.replace("-", "_"))
    readonly property color ink: "#0a0c0f"
    readonly property color accent: "#aebfff"
    readonly property color danger: "#ff5a47"
    readonly property string fontFamily: "IBM Plex Sans"
    property int vosSession: -1
    // The session to start: V-OS's, unless another is chosen below.
    property int chosenSession: -1
    readonly property int sessionIndex: chosenSession >= 0 ? chosenSession : vosSession >= 0 ? vosSession : sessionModel.lastIndex
    property string sessionName: ""
    property bool choosingSession: false
    property int userIndex: userModel.lastIndex >= 0 ? userModel.lastIndex : 0
    property string userName: ""
    property string userTitle: ""
    property string userIcon: ""
    // A picture the user chose: not one of the login manager's stock faces (those are the
    // distribution's, so the first letter of the name stands in for them).
    readonly property bool ownPicture: userIcon.length > 0 && userIcon.indexOf("/usr/share/sddm/") < 0
    property string message: ""
    property real time: 0

    function tr(english, russian) {
        return russian && root.russian ? russian : english;
    }

    // V-OS by its name; any other desktop of the computer only as the fallback (no KDE, no
    // Plasma, no Linux in sight - it is there for when V-OS cannot start).
    function sessionTitle(file, name) {
        return String(file).endsWith("vos.desktop") ? name : root.tr("Fallback desktop", "Резервный рабочий стол");
    }

    function logIn() {
        if (root.userName.length === 0)
            return;
        root.message = "";
        busy.running = true;
        sddm.login(root.userName, password.text, root.sessionIndex);
    }

    width: 1920
    height: 1080

    // Which of the sessions is V-OS's ("vos.desktop"), and the name of the one that will start.
    Repeater {
        model: sessionModel

        delegate: Item {
            required property int index
            required property string file
            required property string name

            readonly property bool starts: index === root.sessionIndex

            onStartsChanged: if (starts) root.sessionName = root.sessionTitle(file, name)
            Component.onCompleted: {
                if (String(file).endsWith("vos.desktop"))
                    root.vosSession = index;
                if (starts)
                    root.sessionName = root.sessionTitle(file, name);
            }
        }
    }

    // The user shown: the one who logged in last, or the one chosen below.
    Repeater {
        model: userModel

        delegate: Item {
            required property int index
            required property string name
            required property string realName
            required property string icon

            readonly property bool chosen: index === root.userIndex

            onChosenChanged: take()
            Component.onCompleted: take()

            function take() {
                if (!chosen)
                    return;
                root.userName = name;
                root.userTitle = realName.length > 0 ? realName : name;
                root.userIcon = icon;
            }
        }
    }

    Connections {
        target: sddm

        function onLoginFailed() {
            busy.running = false;
            root.message = root.tr("That password did not fit. Try again.", "Пароль не подошёл. Попробуйте ещё раз.");
            password.text = "";
            shake.restart();
            password.forceActiveFocus();
        }
    }

    // ---- The horizon of V-OS ------------------------------------------------------------
    Rectangle {
        anchors.fill: parent
        color: root.ink
    }

    ShaderEffect {
        property real time: root.time
        property size resolution: Qt.size(width, height)
        property vector4d accent: Qt.vector4d(0.682, 0.749, 1.0, 1)
        property vector2d pointer: Qt.vector2d(0, 0)
        property real dayHour: new Date().getHours() + new Date().getMinutes() / 60
        property real glow: Number(config.glow ?? 1)
        property real starAmount: 1

        anchors.fill: parent
        fragmentShader: "field.frag.qsb"
    }

    Timer {
        interval: 40
        repeat: true
        running: true
        onTriggered: root.time += 0.04
    }

    // ---- The time ------------------------------------------------------------------------
    Column {
        id: clock

        property date now: new Date()

        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.12
        spacing: 4

        Timer {
            interval: 1000
            repeat: true
            running: true
            onTriggered: clock.now = new Date()
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: Qt.formatTime(clock.now, "HH:mm")
            color: "white"
            font.family: root.fontFamily
            font.pixelSize: Math.min(132, root.height * 0.13)
            font.weight: Font.Light
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: clock.now.toLocaleDateString(root.languageLocale, "dddd, d MMMM")
            color: Qt.rgba(1, 1, 1, 0.72)
            font.family: root.fontFamily
            font.pixelSize: 20
        }
    }

    // ---- The user and the password ---------------------------------------------------------
    Column {
        id: card

        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height * 0.5 - 40
        width: 340
        spacing: 16

        transform: Translate {
            id: shift
        }

        SequentialAnimation {
            id: shake

            NumberAnimation { target: shift; property: "x"; to: -14; duration: 60 }
            NumberAnimation { target: shift; property: "x"; to: 12; duration: 70 }
            NumberAnimation { target: shift; property: "x"; to: -8; duration: 70 }
            NumberAnimation { target: shift; property: "x"; to: 0; duration: 80 }
        }

        // The picture of the user, or the first letter of the name.
        Rectangle {
            anchors.horizontalCenter: parent.horizontalCenter
            width: 104
            height: 104
            radius: 52
            color: Qt.rgba(1, 1, 1, 0.08)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.22)
            clip: true

            Text {
                anchors.centerIn: parent
                visible: face.status !== Image.Ready
                text: root.userTitle.length > 0 ? root.userTitle.charAt(0).toUpperCase() : ""
                color: "white"
                font.family: root.fontFamily
                font.pixelSize: 44
                font.weight: Font.Light
            }

            Image {
                id: face

                anchors.fill: parent
                source: root.ownPicture ? "file://" + root.userIcon.replace(/^file:\/\//, "") : ""
                fillMode: Image.PreserveAspectCrop
                visible: status === Image.Ready
                layer.enabled: true
                layer.effect: MultiEffect {
                    maskEnabled: true
                    maskSource: faceMask
                }
            }

            Item {
                id: faceMask

                anchors.fill: parent
                visible: false
                layer.enabled: true

                Rectangle {
                    anchors.fill: parent
                    radius: width / 2
                }
            }
        }

        Text {
            anchors.horizontalCenter: parent.horizontalCenter
            text: root.userTitle
            color: "white"
            font.family: root.fontFamily
            font.pixelSize: 22
            font.weight: Font.Medium
        }

        // The password: Enter logs in.
        Rectangle {
            width: parent.width
            height: 48
            radius: 24
            color: Qt.rgba(0, 0, 0, 0.42)
            border.width: 1
            border.color: password.activeFocus ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.6) : Qt.rgba(1, 1, 1, 0.16)

            TextInput {
                id: password

                anchors.fill: parent
                anchors.leftMargin: 20
                anchors.rightMargin: 52
                verticalAlignment: TextInput.AlignVCenter
                echoMode: TextInput.Password
                passwordCharacter: "●"
                color: "white"
                selectionColor: root.accent
                font.family: root.fontFamily
                font.pixelSize: 16
                focus: true
                clip: true
                enabled: !busy.running
                onAccepted: root.logIn()

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    visible: password.text.length === 0
                    text: root.tr("Password", "Пароль")
                    color: Qt.rgba(1, 1, 1, 0.42)
                    font: password.font
                }
            }

            // The arrow that logs in.
            Rectangle {
                anchors.right: parent.right
                anchors.rightMargin: 6
                anchors.verticalCenter: parent.verticalCenter
                width: 36
                height: 36
                radius: 18
                color: go.containsMouse ? Qt.lighter(root.accent, 1.08) : root.accent
                opacity: password.text.length > 0 ? 1 : 0.5

                Text {
                    anchors.centerIn: parent
                    text: busy.running ? "…" : "→"
                    color: root.ink
                    font.family: root.fontFamily
                    font.pixelSize: 18
                    font.weight: Font.DemiBold
                }

                MouseArea {
                    id: go

                    anchors.fill: parent
                    hoverEnabled: true
                    onClicked: root.logIn()
                }
            }
        }

        Text {
            width: parent.width
            horizontalAlignment: Text.AlignHCenter
            visible: root.message.length > 0
            text: root.message
            color: root.danger
            font.family: root.fontFamily
            font.pixelSize: 14
            wrapMode: Text.Wrap
        }

        Timer {
            id: busy

            property bool running: false

            interval: 15000
            onTriggered: running = false
        }
    }

    // ---- Other users, when there are several --------------------------------------------------
    Row {
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 40
        spacing: 14
        visible: userModel.count > 1

        Repeater {
            model: userModel

            delegate: Rectangle {
                required property int index
                required property string realName
                required property string name

                width: 44
                height: 44
                radius: 22
                color: index === root.userIndex ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.35) : Qt.rgba(1, 1, 1, 0.08)
                border.width: 1
                border.color: Qt.rgba(1, 1, 1, 0.2)

                Text {
                    anchors.centerIn: parent
                    text: (realName.length > 0 ? realName : name).charAt(0).toUpperCase()
                    color: "white"
                    font.family: root.fontFamily
                    font.pixelSize: 18
                }

                MouseArea {
                    anchors.fill: parent
                    onClicked: {
                        root.userIndex = parent.index;
                        password.text = "";
                        password.forceActiveFocus();
                    }
                }
            }
        }
    }

    // ---- The keyboard layout and the computer ------------------------------------------------
    Row {
        anchors.right: parent.right
        anchors.bottom: parent.bottom
        anchors.margins: 28
        spacing: 10

        component PowerButton: Rectangle {
            id: button

            property string label
            signal activated()

            width: text.implicitWidth + 32
            height: 40
            radius: 20
            color: hover.containsMouse ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(1, 1, 1, 0.08)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.14)

            Text {
                id: text

                anchors.centerIn: parent
                text: button.label
                color: "white"
                font.family: root.fontFamily
                font.pixelSize: 14
            }

            MouseArea {
                id: hover

                anchors.fill: parent
                hoverEnabled: true
                onClicked: button.activated()
            }
        }

        PowerButton {
            visible: keyboard.layouts.length > 1
            label: keyboard.layouts.length > 0 ? String(keyboard.layouts[keyboard.currentLayout].shortName).toUpperCase() : ""
            onActivated: keyboard.currentLayout = (keyboard.currentLayout + 1) % keyboard.layouts.length
        }

        PowerButton {
            visible: sddm.canSuspend
            label: root.tr("Sleep", "Сон")
            onActivated: sddm.suspend()
        }

        PowerButton {
            visible: sddm.canReboot
            label: root.tr("Restart", "Перезагрузить")
            onActivated: sddm.reboot()
        }

        PowerButton {
            visible: sddm.canPowerOff
            label: root.tr("Shut down", "Выключить")
            onActivated: sddm.powerOff()
        }
    }

    // ---- The session: V-OS, or another one the computer has (the way back) ------------------
    Item {
        id: sessionChooser

        anchors.left: parent.left
        anchors.bottom: parent.bottom
        anchors.margins: 28
        width: sessionButton.width
        height: sessionButton.height

        Rectangle {
            id: sessionButton

            objectName: "login.session"
            width: sessionText.implicitWidth + 40
            height: 40
            radius: 20
            color: sessionHover.containsMouse || activeFocus ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(1, 1, 1, 0.08)
            border.width: 1
            border.color: activeFocus ? Qt.rgba(root.accent.r, root.accent.g, root.accent.b, 0.6) : Qt.rgba(1, 1, 1, 0.14)
            activeFocusOnTab: true
            Keys.onReturnPressed: root.choosingSession = !root.choosingSession
            Keys.onSpacePressed: root.choosingSession = !root.choosingSession
            Keys.onEscapePressed: root.choosingSession = false

            Text {
                id: sessionText

                anchors.centerIn: parent
                text: (root.sessionName.length > 0 ? root.sessionName : "V-OS") + "  ▾"
                color: Qt.rgba(1, 1, 1, 0.86)
                font.family: root.fontFamily
                font.pixelSize: 14
            }

            MouseArea {
                id: sessionHover

                anchors.fill: parent
                hoverEnabled: true
                onClicked: root.choosingSession = !root.choosingSession
            }
        }

        // The sessions, above the button.
        Rectangle {
            visible: root.choosingSession
            anchors.left: parent.left
            anchors.bottom: sessionButton.top
            anchors.bottomMargin: 10
            width: 320
            height: sessions.contentHeight + 16
            radius: 16
            color: Qt.rgba(0.06, 0.07, 0.09, 0.96)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.14)

            ListView {
                id: sessions

                anchors.fill: parent
                anchors.margins: 8
                interactive: false
                model: sessionModel

                delegate: Rectangle {
                    required property int index
                    required property string name
                    required property string file

                    width: ListView.view.width
                    height: 40
                    radius: 10
                    color: pick.containsMouse ? Qt.rgba(1, 1, 1, 0.10) : "transparent"

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        x: 14
                        text: (index === root.sessionIndex ? "●  " : "    ") + root.sessionTitle(file, name)
                        color: "white"
                        font.family: root.fontFamily
                        font.pixelSize: 14
                    }

                    MouseArea {
                        id: pick

                        anchors.fill: parent
                        hoverEnabled: true
                        onClicked: {
                            root.chosenSession = index;
                            root.choosingSession = false;
                            password.forceActiveFocus();
                        }
                    }
                }
            }
        }
    }

    Component.onCompleted: {
        password.forceActiveFocus();
        // (For the test of the login screen: the V-OS look is shown, not the plain stand-in.)
        console.info("V-OS login: ready");
    }
}
